import React from "react";

function Feed() {
  return <div>Feed</div>;
}

export default Feed;
