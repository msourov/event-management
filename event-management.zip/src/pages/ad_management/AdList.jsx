import React from 'react'

function AdList() {
  return (
    <div>AdList</div>
  )
}

export default AdList