import React from 'react'

function Doctors() {
  return (
    <div>Doctors</div>
  )
}

export default Doctors