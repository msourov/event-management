import { useDispatch, useSelector } from "react-redux";
import { logout } from "../state/reducers/loginSlice";

const Logout = () => {
    const user = useSelector()
}