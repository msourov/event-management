import React from "react";

function Signup() {
  return <div></div>;
}

export default Signup;
