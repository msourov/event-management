import React from 'react'

function AppUser() {
  return (
    <div>AppUser</div>
  )
}

export default AppUser