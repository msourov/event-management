import React from 'react'

function Storage() {
  return (
    <div>Storage</div>
  )
}

export default Storage